const express = require('express');
const db = require('../models/database');
const { authenticateToken } = require('../middleware/auth');
const { calculateGuessPoints, checkRankUp } = require('../src/rankSystem');

const router = express.Router();

// 词语关联知识库
const wordRelations = {
  '苹果': ['水果', '红色', '甜', '牛顿', '手机', '乔布斯', '吃', '健康', '维生素', '果汁'],
  '香蕉': ['水果', '黄色', '甜', '猴子', '热带', '吃', '健康', '剥皮', '牛奶'],
  '西瓜': ['水果', '绿色', '红色', '甜', '夏天', '解渴', '大', '籽', '冰镇'],
  '葡萄': ['水果', '紫色', '一串', '甜', '酸', '葡萄酒', '葡萄干'],
  '草莓': ['水果', '红色', '甜', '奶油', '蛋糕', '夏天', '小'],
  '电脑': ['电子', '科技', '工作', '游戏', '上网', '编程', 'Windows', 'Mac'],
  '手机': ['电子', '通讯', '打电话', '微信', '拍照', '苹果', '华为', '小米'],
  '平板': ['电子', '大屏', '看视频', '画画', 'iPad', '安卓'],
  '耳机': ['电子', '听音乐', '蓝牙', '降噪', '无线', '索尼', 'AirPods'],
  '键盘': ['电子', '打字', '机械', '游戏', '电脑', '输入'],
  '北京': ['首都', '中国', '天安门', '故宫', '长城', '北方', '雾霾'],
  '上海': ['中国', '东方明珠', '外滩', '魔都', '经济', '南方'],
  '广州': ['中国', '广东', '粤语', '美食', '南方', '羊城'],
  '深圳': ['中国', '广东', '科技', '腾讯', '华为', '年轻'],
  '成都': ['中国', '四川', '火锅', '熊猫', '辣', '休闲'],
  '李白': ['诗人', '唐朝', '诗仙', '酒', '月亮', '杜甫', '诗歌'],
  '杜甫': ['诗人', '唐朝', '诗圣', '忧国忧民', '李白', '诗歌'],
  '苏轼': ['诗人', '宋朝', '东坡肉', '书法', '唐宋八大家'],
  '曹操': ['三国', '魏国', '奸雄', '军事家', '诗人', '刘备'],
  '诸葛亮': ['三国', '蜀国', '智慧', '军师', '刘备', '空城计']
};

// 计算词语相似度
function calculateSimilarity(word1, word2) {
  word1 = word1.trim();
  word2 = word2.trim();
  
  if (word1 === word2) return 100;
  if (word1.includes(word2) || word2.includes(word1)) return 80;
  
  const relations1 = wordRelations[word1] || [];
  const relations2 = wordRelations[word2] || [];
  
  if (relations1.includes(word2) || relations2.includes(word1)) return 70;
  
  const commonRelations = relations1.filter(r => relations2.includes(r));
  if (commonRelations.length > 0) {
    return Math.min(50 + commonRelations.length * 10, 75);
  }
  
  // 简单字符串相似度
  let sameChars = 0;
  for (let c of word1) {
    if (word2.includes(c)) sameChars++;
  }
  const similarity = (sameChars / Math.max(word1.length, word2.length)) * 30;
  
  return Math.max(5, Math.floor(similarity));
}

// 获取今日目标词
router.get('/daily-word', (req, res) => {
  const today = new Date().toISOString().split('T')[0];
  
  let dailyWord = db.prepare(`SELECT dw.*, w.word, w.category 
          FROM daily_words dw 
          JOIN words w ON dw.word_id = w.id 
          WHERE dw.date = ?`).get(today);
  
  if (dailyWord) {
    const now = new Date();
    const wordLength = dailyWord.word.length;
    let revealedChars = dailyWord.revealed_chars;
    
    if (dailyWord.last_reveal_time) {
      const lastReveal = new Date(dailyWord.last_reveal_time);
      const minutesPassed = (now - lastReveal) / (1000 * 60);
      
      if (minutesPassed >= 3 && revealedChars < wordLength) {
        revealedChars = Math.min(revealedChars + 1, wordLength);
        db.prepare('UPDATE daily_words SET revealed_chars = ?, last_reveal_time = ? WHERE id = ?')
          .run(revealedChars, now.toISOString(), dailyWord.id);
      }
    } else {
      db.prepare('UPDATE daily_words SET last_reveal_time = ? WHERE id = ?')
        .run(now.toISOString(), dailyWord.id);
    }
    
    const nextRevealTime = dailyWord.last_reveal_time 
      ? new Date(new Date(dailyWord.last_reveal_time).getTime() + 3 * 60 * 1000)
      : new Date(now.getTime() + 3 * 60 * 1000);
    
    const secondsToNextReveal = Math.max(0, Math.floor((nextRevealTime - now) / 1000));
    
    return res.json({
      wordLength,
      category: dailyWord.category,
      revealedChars,
      revealedPart: dailyWord.word.substring(0, revealedChars),
      secondsToNextReveal,
      date: today
    });
  }
  
  // 如果没有今日词语，随机选一个
  const word = db.prepare('SELECT * FROM words ORDER BY RANDOM() LIMIT 1').get();
  if (!word) {
    return res.status(500).json({ error: '没有可用词语' });
  }
  
  const now = new Date();
  db.prepare('INSERT INTO daily_words (word_id, date, revealed_chars, last_reveal_time) VALUES (?, ?, 0, ?)')
    .run(word.id, today, now.toISOString());
  
  res.json({
    wordLength: word.word.length,
    category: word.category,
    revealedChars: 0,
    revealedPart: '',
    secondsToNextReveal: 180,
    date: today
  });
});

// 提交猜测
router.post('/guess', authenticateToken, (req, res) => {
  const { guessWord } = req.body;
  const today = new Date().toISOString().split('T')[0];
  
  if (!guessWord || guessWord.trim() === '') {
    return res.status(400).json({ error: '请输入猜测词语' });
  }
  
  const dailyWord = db.prepare(`SELECT dw.id as daily_word_id, w.word as target_word, w.category
          FROM daily_words dw 
          JOIN words w ON dw.word_id = w.id 
          WHERE dw.date = ?`).get(today);
  
  if (!dailyWord) {
    return res.status(500).json({ error: '游戏未初始化' });
  }
  
  const similarity = calculateSimilarity(guessWord, dailyWord.target_word);
  const isCorrect = guessWord === dailyWord.target_word;
  
  // 保存猜测记录
  db.prepare(`INSERT INTO guesses (user_id, daily_word_id, guess_word, similarity, is_correct) 
            VALUES (?, ?, ?, ?, ?)`)
    .run(req.user.userId, dailyWord.daily_word_id, guessWord, similarity, isCorrect ? 1 : 0);
  
  // 计算得分并更新段位
  const userRank = db.prepare(`SELECT ur.*, s.id as season_id
                FROM user_ranks ur 
                JOIN seasons s ON ur.season_id = s.id 
                WHERE ur.user_id = ? AND s.is_active = 1`)
    .get(req.user.userId);
  
  const pointsGained = calculateGuessPoints(similarity, isCorrect, 0);
  const result = checkRankUp(
    userRank?.rank || '青铜',
    userRank?.stars || 0,
    userRank?.points || 0,
    pointsGained
  );
  
  if (userRank) {
    db.prepare(`UPDATE user_ranks SET rank = ?, stars = ?, points = ?, 
            total_guesses = total_guesses + 1, 
            correct_guesses = correct_guesses + ? 
            WHERE id = ?`)
      .run(result.newRank, result.newStars, result.newPoints, isCorrect ? 1 : 0, userRank.id);
  }
  
  res.json({
    similarity,
    isCorrect,
    targetWord: isCorrect ? dailyWord.target_word : null,
    pointsGained,
    rankUp: result.rankUp,
    newRank: result.newRank
  });
});

// 获取猜测历史
router.get('/guesses', authenticateToken, (req, res) => {
  const today = new Date().toISOString().split('T')[0];
  
  const guesses = db.prepare(`SELECT g.*, u.username 
          FROM guesses g 
          JOIN users u ON g.user_id = u.id
          JOIN daily_words dw ON g.daily_word_id = dw.id
          WHERE dw.date = ?
          ORDER BY g.similarity DESC, g.created_at ASC`)
    .all(today);
  
  res.json({ guesses: guesses || [] });
});

// 排行榜
router.get('/leaderboard', (req, res) => {
  const leaderboard = db.prepare(`SELECT u.username, ur.points, ur.rank, ur.correct_guesses, ur.total_guesses
          FROM user_ranks ur
          JOIN users u ON ur.user_id = u.id
          JOIN seasons s ON ur.season_id = s.id
          WHERE s.is_active = 1
          ORDER BY ur.points DESC
          LIMIT 50`).all();
  
  res.json({ leaderboard: leaderboard || [] });
});

// 统计数据
router.get('/stats', (req, res) => {
  const today = new Date().toISOString().split('T')[0];
  
  const users = db.prepare('SELECT COUNT(*) as count FROM users').get();
  const guesses = db.prepare(`SELECT COUNT(*) as count FROM guesses g
            JOIN daily_words dw ON g.daily_word_id = dw.id
            WHERE dw.date = ?`).get(today);
  const players = db.prepare(`SELECT COUNT(DISTINCT user_id) as count FROM guesses g
              JOIN daily_words dw ON g.daily_word_id = dw.id
              WHERE dw.date = ?`).get(today);
  
  res.json({
    totalUsers: users.count,
    todayGuesses: guesses.count,
    todayPlayers: players.count
  });
});

module.exports = router;
