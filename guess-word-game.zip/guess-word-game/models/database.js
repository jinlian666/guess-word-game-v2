const Database = require('better-sqlite3');
const path = require('path');
const bcrypt = require('bcryptjs');

const dbPath = path.join(__dirname, '..', 'database.db');
const db = new Database(dbPath);

// 初始化表
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    email TEXT,
    is_admin INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS user_ranks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    season_id INTEGER NOT NULL,
    rank TEXT DEFAULT '青铜',
    stars INTEGER DEFAULT 0,
    points INTEGER DEFAULT 0,
    total_guesses INTEGER DEFAULT 0,
    correct_guesses INTEGER DEFAULT 0,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (season_id) REFERENCES seasons(id),
    UNIQUE(user_id, season_id)
  );

  CREATE TABLE IF NOT EXISTS seasons (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    start_date DATETIME NOT NULL,
    end_date DATETIME NOT NULL,
    is_active INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS words (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    word TEXT NOT NULL,
    category TEXT NOT NULL,
    difficulty INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS daily_words (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    word_id INTEGER NOT NULL,
    date DATE NOT NULL UNIQUE,
    revealed_chars INTEGER DEFAULT 0,
    last_reveal_time DATETIME,
    FOREIGN KEY (word_id) REFERENCES words(id)
  );

  CREATE TABLE IF NOT EXISTS guesses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    daily_word_id INTEGER NOT NULL,
    guess_word TEXT NOT NULL,
    similarity REAL NOT NULL,
    is_correct INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (daily_word_id) REFERENCES daily_words(id)
  );
`);

// 插入默认管理员
const adminExists = db.prepare('SELECT id FROM users WHERE username = ?').get('admin');
if (!adminExists) {
  const hashedPassword = bcrypt.hashSync('admin123', 10);
  db.prepare('INSERT INTO users (username, password, is_admin) VALUES (?, ?, ?)')
    .run('admin', hashedPassword, 1);
}

// 插入默认词语
const defaultWords = [
  { word: '苹果', category: '水果' },
  { word: '香蕉', category: '水果' },
  { word: '西瓜', category: '水果' },
  { word: '葡萄', category: '水果' },
  { word: '草莓', category: '水果' },
  { word: '电脑', category: '电子产品' },
  { word: '手机', category: '电子产品' },
  { word: '平板', category: '电子产品' },
  { word: '耳机', category: '电子产品' },
  { word: '键盘', category: '电子产品' },
  { word: '北京', category: '城市' },
  { word: '上海', category: '城市' },
  { word: '广州', category: '城市' },
  { word: '深圳', category: '城市' },
  { word: '成都', category: '城市' },
  { word: '李白', category: '历史人物' },
  { word: '杜甫', category: '历史人物' },
  { word: '苏轼', category: '历史人物' },
  { word: '曹操', category: '历史人物' },
  { word: '诸葛亮', category: '历史人物' }
];

const insertWord = db.prepare('INSERT OR IGNORE INTO words (word, category) VALUES (?, ?)');
defaultWords.forEach(({ word, category }) => {
  insertWord.run(word, category);
});

// 创建默认赛季
const activeSeason = db.prepare('SELECT id FROM seasons WHERE is_active = 1').get();
if (!activeSeason) {
  const now = new Date();
  const end = new Date(now);
  end.setMonth(end.getMonth() + 1);
  db.prepare('INSERT INTO seasons (name, start_date, end_date, is_active) VALUES (?, ?, ?, ?)')
    .run('S1赛季', now.toISOString(), end.toISOString(), 1);
}

module.exports = db;
