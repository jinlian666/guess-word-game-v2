const natural = require('natural');

// 词语关联知识库
const wordRelations = {
  // 水果类
  '苹果': ['水果', '红色', '甜', '牛顿', '手机', '乔布斯', '吃', '健康', '维生素', '果汁'],
  '香蕉': ['水果', '黄色', '甜', '猴子', '热带', '吃', '健康', '剥皮', '牛奶'],
  '西瓜': ['水果', '绿色', '红色', '甜', '夏天', '解渴', '大', '籽', '冰镇'],
  '葡萄': ['水果', '紫色', '一串', '甜', '酸', '葡萄酒', '葡萄干'],
  '草莓': ['水果', '红色', '甜', '奶油', '蛋糕', '夏天', '小'],
  
  // 电子产品
  '电脑': ['电子', '科技', '工作', '游戏', '上网', '编程', 'Windows', 'Mac'],
  '手机': ['电子', '通讯', '打电话', '微信', '拍照', '苹果', '华为', '小米'],
  '平板': ['电子', '大屏', '看视频', '画画', 'iPad', '安卓'],
  '耳机': ['电子', '听音乐', '蓝牙', '降噪', '无线', '索尼', 'AirPods'],
  '键盘': ['电子', '打字', '机械', '游戏', '电脑', '输入'],
  
  // 城市
  '北京': ['首都', '中国', '天安门', '故宫', '长城', '北方', '雾霾'],
  '上海': ['中国', '东方明珠', '外滩', '魔都', '经济', '南方'],
  '广州': ['中国', '广东', '粤语', '美食', '南方', '羊城'],
  '深圳': ['中国', '广东', '科技', '腾讯', '华为', '年轻'],
  '成都': ['中国', '四川', '火锅', '熊猫', '辣', '休闲'],
  
  // 历史人物
  '李白': ['诗人', '唐朝', '诗仙', '酒', '月亮', '杜甫', '诗歌'],
  '杜甫': ['诗人', '唐朝', '诗圣', '忧国忧民', '李白', '诗歌'],
  '苏轼': ['诗人', '宋朝', '东坡肉', '书法', '唐宋八大家'],
  '曹操': ['三国', '魏国', '奸雄', '军事家', '诗人', '刘备'],
  '诸葛亮': ['三国', '蜀国', '智慧', '军师', '刘备', '空城计']
};

// 计算词语相似度
function calculateSimilarity(word1, word2) {
  word1 = word1.trim();
  word2 = word2.trim();
  
  // 完全匹配
  if (word1 === word2) return 100;
  
  // 包含关系
  if (word1.includes(word2) || word2.includes(word1)) return 80;
  
  // 获取关联词列表
  const relations1 = wordRelations[word1] || [];
  const relations2 = wordRelations[word2] || [];
  
  // 检查是否在对方的关联词中
  if (relations1.includes(word2) || relations2.includes(word1)) return 70;
  
  // 计算共同关联词数量
  const commonRelations = relations1.filter(r => relations2.includes(r));
  if (commonRelations.length > 0) {
    return 50 + commonRelations.length * 10;
  }
  
  // 使用字符串相似度作为兜底
  const distance = natural.LevenshteinDistance(word1, word2);
  const maxLen = Math.max(word1.length, word2.length);
  const similarity = ((maxLen - distance) / maxLen) * 30;
  
  return Math.max(5, Math.min(similarity, 50));
}

module.exports = { calculateSimilarity, wordRelations };
