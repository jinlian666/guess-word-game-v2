// 段位配置
const RANKS = [
  { name: '青铜', minPoints: 0, starsNeeded: 3, color: '#CD7F32' },
  { name: '白银', minPoints: 100, starsNeeded: 3, color: '#C0C0C0' },
  { name: '黄金', minPoints: 300, starsNeeded: 4, color: '#FFD700' },
  { name: '铂金', minPoints: 600, starsNeeded: 4, color: '#E5E4E2' },
  { name: '钻石', minPoints: 1000, starsNeeded: 5, color: '#B9F2FF' },
  { name: '星耀', minPoints: 1500, starsNeeded: 5, color: '#9370DB' },
  { name: '王者', minPoints: 2200, starsNeeded: Infinity, color: '#FF6B6B' }
];

// 计算当前段位
function calculateRank(points) {
  for (let i = RANKS.length - 1; i >= 0; i--) {
    if (points >= RANKS[i].minPoints) {
      return RANKS[i];
    }
  }
  return RANKS[0];
}

// 计算猜词得分
function calculateGuessPoints(similarity, isCorrect, guessCount) {
  if (isCorrect) {
    // 猜对奖励
    const basePoints = 100;
    const bonus = Math.max(0, 50 - guessCount * 5);
    return basePoints + bonus;
  }
  
  // 关联度得分
  if (similarity >= 70) return 20;
  if (similarity >= 50) return 10;
  if (similarity >= 30) return 5;
  return 1;
}

// 检查是否升星/升段
function checkRankUp(currentRank, currentStars, currentPoints, newPoints) {
  const totalPoints = currentPoints + newPoints;
  const newRank = calculateRank(totalPoints);
  const rankIndex = RANKS.findIndex(r => r.name === newRank.name);
  
  let stars = currentStars;
  let rankUp = false;
  let newRankName = currentRank;
  
  if (newRank.name !== currentRank) {
    rankUp = true;
    newRankName = newRank.name;
    stars = 0;
  } else {
    stars += 1;
    if (stars >= newRank.starsNeeded && rankIndex < RANKS.length - 1) {
      rankUp = true;
      newRankName = RANKS[rankIndex + 1].name;
      stars = 0;
    }
  }
  
  return {
    newRank: newRankName,
    newStars: stars,
    newPoints: totalPoints,
    rankUp,
    pointsGained: newPoints
  };
}

module.exports = { RANKS, calculateRank, calculateGuessPoints, checkRankUp };
