const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../models/database');
const { authenticateToken } = require('../middleware/auth');

const router = express.Router();

// 注册
router.post('/register', (req, res) => {
  const { username, password } = req.body;
  
  if (!username || !password) {
    return res.status(400).json({ error: '用户名和密码不能为空' });
  }
  
  if (username.length < 3 || username.length > 20) {
    return res.status(400).json({ error: '用户名长度3-20字符' });
  }
  
  if (password.length < 6) {
    return res.status(400).json({ error: '密码至少6位' });
  }
  
  const existing = db.prepare('SELECT id FROM users WHERE username = ?').get(username);
  if (existing) {
    return res.status(400).json({ error: '用户名已存在' });
  }
  
  const hashedPassword = bcrypt.hashSync(password, 10);
  const result = db.prepare('INSERT INTO users (username, password) VALUES (?, ?)')
    .run(username, hashedPassword);
  
  const userId = result.lastInsertRowid;
  
  // 创建用户段位记录
  const season = db.prepare('SELECT id FROM seasons WHERE is_active = 1').get();
  if (season) {
    db.prepare('INSERT INTO user_ranks (user_id, season_id) VALUES (?, ?)')
      .run(userId, season.id);
  }
  
  const token = jwt.sign(
    { userId, username, isAdmin: false },
    process.env.JWT_SECRET,
    { expiresIn: '30d' }
  );
  
  res.json({ token, user: { id: userId, username, isAdmin: false } });
});

// 登录
router.post('/login', (req, res) => {
  const { username, password } = req.body;
  
  const user = db.prepare('SELECT * FROM users WHERE username = ?').get(username);
  if (!user || !bcrypt.compareSync(password, user.password)) {
    return res.status(400).json({ error: '用户名或密码错误' });
  }
  
  const token = jwt.sign(
    { userId: user.id, username: user.username, isAdmin: user.is_admin === 1 },
    process.env.JWT_SECRET,
    { expiresIn: '30d' }
  );
  
  res.json({ 
    token, 
    user: { 
      id: user.id, 
      username: user.username, 
      isAdmin: user.is_admin === 1 
    } 
  });
});

// 获取用户信息
router.get('/profile', authenticateToken, (req, res) => {
  const user = db.prepare('SELECT id, username, is_admin FROM users WHERE id = ?').get(req.user.userId);
  if (!user) {
    return res.status(404).json({ error: '用户不存在' });
  }
  
  const rank = db.prepare(`SELECT ur.*, s.name as season_name 
          FROM user_ranks ur 
          JOIN seasons s ON ur.season_id = s.id 
          WHERE ur.user_id = ? AND s.is_active = 1`).get(req.user.userId);
  
  res.json({
    user: { id: user.id, username: user.username, isAdmin: user.is_admin === 1 },
    rank: rank || { rank: '青铜', stars: 0, points: 0 }
  });
});

module.exports = router;
