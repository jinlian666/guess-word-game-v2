const express = require('express');
const db = require('../models/database');
const { authenticateToken, isAdmin } = require('../middleware/auth');

const router = express.Router();

// 词语管理
router.get('/words', authenticateToken, isAdmin, (req, res) => {
  const words = db.prepare('SELECT * FROM words ORDER BY created_at DESC').all();
  res.json({ words: words || [] });
});

router.post('/words', authenticateToken, isAdmin, (req, res) => {
  const { word, category, difficulty } = req.body;
  
  if (!word || !category) {
    return res.status(400).json({ error: '词语和分类不能为空' });
  }
  
  const result = db.prepare('INSERT INTO words (word, category, difficulty) VALUES (?, ?, ?)')
    .run(word, category, difficulty || 1);
  
  res.json({ id: result.lastInsertRowid, word, category, difficulty });
});

router.delete('/words/:id', authenticateToken, isAdmin, (req, res) => {
  db.prepare('DELETE FROM words WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

// 用户管理
router.get('/users', authenticateToken, isAdmin, (req, res) => {
  const users = db.prepare(`SELECT u.id, u.username, u.is_admin, u.created_at,
          ur.rank, ur.points, ur.total_guesses, ur.correct_guesses
          FROM users u
          LEFT JOIN user_ranks ur ON u.id = ur.user_id
          LEFT JOIN seasons s ON ur.season_id = s.id AND s.is_active = 1
          ORDER BY u.created_at DESC`).all();
  res.json({ users: users || [] });
});

router.put('/users/:id/admin', authenticateToken, isAdmin, (req, res) => {
  const { isAdmin } = req.body;
  db.prepare('UPDATE users SET is_admin = ? WHERE id = ?')
    .run(isAdmin ? 1 : 0, req.params.id);
  res.json({ success: true });
});

// 赛季管理
router.get('/seasons', authenticateToken, isAdmin, (req, res) => {
  const seasons = db.prepare('SELECT * FROM seasons ORDER BY created_at DESC').all();
  res.json({ seasons: seasons || [] });
});

router.post('/seasons', authenticateToken, isAdmin, (req, res) => {
  const { name, startDate, endDate } = req.body;
  
  db.prepare('UPDATE seasons SET is_active = 0').run();
  const result = db.prepare('INSERT INTO seasons (name, start_date, end_date, is_active) VALUES (?, ?, ?, 1)')
    .run(name, startDate, endDate);
  
  res.json({ id: result.lastInsertRowid, name, startDate, endDate });
});

module.exports = router;
