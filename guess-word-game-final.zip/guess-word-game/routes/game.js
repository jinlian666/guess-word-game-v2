const express = require('express');
const db = require('../models/database');
const { authenticateToken } = require('../middleware/auth');
const { calculateGuessPoints, checkRankUp } = require('../src/rankSystem');

const router = express.Router();

// 词语关联知识库
const wordRelations = {
  '苹果': ['水果', '红色', '甜', '牛顿', '手机', '乔布斯', '吃', '健康', '维生素', '果汁', '平安'],
  '香蕉': ['水果', '黄色', '甜', '猴子', '热带', '吃', '健康', '剥皮', '牛奶', '润肠'],
  '西瓜': ['水果', '绿色', '红色', '甜', '夏天', '解渴', '大', '籽', '冰镇', '瓜'],
  '葡萄': ['水果', '紫色', '一串', '甜', '酸', '葡萄酒', '葡萄干', '提子'],
  '草莓': ['水果', '红色', '甜', '奶油', '蛋糕', '夏天', '小', '莓'],
  '芒果': ['水果', '黄色', '甜', '热带', '香', '多汁'],
  '橙子': ['水果', '橙色', '酸', '甜', '维C', '橘子', '柑'],
  '樱桃': ['水果', '红色', '小', '甜', '车厘子'],
  '电脑': ['电子', '科技', '工作', '游戏', '上网', '编程', 'Windows', 'Mac', '笔记本'],
  '手机': ['电子', '通讯', '打电话', '微信', '拍照', '苹果', '华为', '小米', '智能'],
  '平板': ['电子', '大屏', '看视频', '画画', 'iPad', '安卓', '电脑'],
  '耳机': ['电子', '听音乐', '蓝牙', '降噪', '无线', '索尼', 'AirPods', '声音'],
  '键盘': ['电子', '打字', '机械', '游戏', '电脑', '输入', '鼠标'],
  '鼠标': ['电子', '点击', '电脑', '游戏', '无线', '指针'],
  '手表': ['电子', '时间', '智能', '苹果', '华为', '戴', '手环'],
  '北京': ['首都', '中国', '天安门', '故宫', '长城', '北方', '烤鸭'],
  '上海': ['中国', '东方明珠', '外滩', '魔都', '经济', '南方', '繁华'],
  '广州': ['中国', '广东', '粤语', '美食', '南方', '羊城', '早茶'],
  '深圳': ['中国', '广东', '科技', '腾讯', '华为', '年轻', '创新'],
  '成都': ['中国', '四川', '火锅', '熊猫', '辣', '休闲', '天府'],
  '杭州': ['中国', '浙江', '西湖', '阿里', '电商', '江南', '美景'],
  '西安': ['中国', '陕西', '兵马俑', '古都', '面食', '历史'],
  '李白': ['诗人', '唐朝', '诗仙', '酒', '月亮', '杜甫', '诗歌', '浪漫'],
  '杜甫': ['诗人', '唐朝', '诗圣', '忧国忧民', '李白', '诗歌', '现实'],
  '苏轼': ['诗人', '宋朝', '东坡肉', '书法', '唐宋八大家', '豪放'],
  '曹操': ['三国', '魏国', '奸雄', '军事家', '诗人', '刘备', '枭雄'],
  '诸葛亮': ['三国', '蜀国', '智慧', '军师', '刘备', '空城计', '卧龙'],
  '关羽': ['三国', '蜀国', '武圣', '义气', '刘备', '张飞', '红脸'],
  '孙悟空': ['西游记', '猴子', '齐天大圣', '唐僧', '金箍棒', '七十二变'],
  '贾宝玉': ['红楼梦', '林黛玉', '大观园', '石头记', '多情'],
  '唐僧': ['西游记', '取经', '和尚', '孙悟空', '八戒', '慈悲'],
  '足球': ['运动', '世界杯', '梅西', 'C罗', '球门', '草地', '11人'],
  '篮球': ['运动', 'NBA', '乔丹', '科比', '姚明', '篮筐', '灌篮'],
  '游泳': ['运动', '水', '泳池', '夏天', '健身', '蛙泳', '自由泳'],
  '跑步': ['运动', '马拉松', '健身', '晨跑', '夜跑', '鞋子'],
  '乒乓球': ['运动', '国球', '中国', '桌子', '拍子', '小球']
};

// 计算词语相似度
function calculateSimilarity(word1, word2) {
  word1 = word1.trim();
  word2 = word2.trim();
  
  if (word1 === word2) return 100;
  if (word1.includes(word2) || word2.includes(word1)) return 80;
  
  const relations1 = wordRelations[word1] || [];
  const relations2 = wordRelations[word2] || [];
  
  if (relations1.includes(word2) || relations2.includes(word1)) return 70;
  
  const commonRelations = relations1.filter(r => relations2.includes(r));
  if (commonRelations.length > 0) {
    return Math.min(50 + commonRelations.length * 8, 75);
  }
  
  let sameChars = 0;
  for (let c of word1) {
    if (word2.includes(c)) sameChars++;
  }
  const similarity = (sameChars / Math.max(word1.length, word2.length)) * 30;
  
  return Math.max(5, Math.floor(similarity));
}

// 获取今日目标词
router.get('/daily-word', authenticateToken, (req, res) => {
  const today = new Date().toISOString().split('T')[0];
  
  let dailyWord = db.prepare(`SELECT dw.*, w.word, w.category 
          FROM daily_words dw 
          JOIN words w ON dw.word_id = w.id 
          WHERE dw.date = ?`).get(today);
  
  if (dailyWord) {
    const now = new Date();
    const wordLength = dailyWord.word.length;
    let revealedChars = dailyWord.revealed_chars;
    
    if (dailyWord.last_reveal_time) {
      const lastReveal = new Date(dailyWord.last_reveal_time);
      const minutesPassed = (now - lastReveal) / (1000 * 60);
      
      if (minutesPassed >= 3 && revealedChars < wordLength) {
        revealedChars = Math.min(revealedChars + 1, wordLength);
        db.prepare('UPDATE daily_words SET revealed_chars = ?, last_reveal_time = ? WHERE id = ?')
          .run(revealedChars, now.toISOString(), dailyWord.id);
      }
    } else {
      db.prepare('UPDATE daily_words SET last_reveal_time = ? WHERE id = ?')
        .run(now.toISOString(), dailyWord.id);
    }
    
    const nextRevealTime = dailyWord.last_reveal_time 
      ? new Date(new Date(dailyWord.last_reveal_time).getTime() + 3 * 60 * 1000)
      : new Date(now.getTime() + 3 * 60 * 1000);
    
    const secondsToNextReveal = Math.max(0, Math.floor((nextRevealTime - now) / 1000));
    
    return res.json({
      wordLength,
      category: dailyWord.category,
      revealedChars,
      revealedPart: dailyWord.word.substring(0, revealedChars),
      secondsToNextReveal,
      date: today
    });
  }
  
  const word = db.prepare('SELECT * FROM words ORDER BY RANDOM() LIMIT 1').get();
  if (!word) {
    return res.status(500).json({ error: '没有可用词语' });
  }
  
  const now = new Date();
  db.prepare('INSERT INTO daily_words (word_id, date, revealed_chars, last_reveal_time) VALUES (?, ?, 0, ?)')
    .run(word.id, today, now.toISOString());
  
  res.json({
    wordLength: word.word.length,
    category: word.category,
    revealedChars: 0,
    revealedPart: '',
    secondsToNextReveal: 180,
    date: today
  });
});

// 提交猜测
router.post('/guess', authenticateToken, (req, res) => {
  const { guessWord, useHint } = req.body;
  const today = new Date().toISOString().split('T')[0];
  
  if (!guessWord || guessWord.trim() === '') {
    return res.status(400).json({ error: '请输入猜测词语' });
  }
  
  const dailyWord = db.prepare(`SELECT dw.id as daily_word_id, w.word as target_word, w.category
          FROM daily_words dw 
          JOIN words w ON dw.word_id = w.id 
          WHERE dw.date = ?`).get(today);
  
  if (!dailyWord) {
    return res.status(500).json({ error: '游戏未初始化' });
  }
  
  const similarity = calculateSimilarity(guessWord, dailyWord.target_word);
  const isCorrect = guessWord === dailyWord.target_word;
  
  db.prepare(`INSERT INTO guesses (user_id, daily_word_id, guess_word, similarity, is_correct) 
            VALUES (?, ?, ?, ?, ?)`)
    .run(req.user.userId, dailyWord.daily_word_id, guessWord, similarity, isCorrect ? 1 : 0);
  
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.userId);
  const userRank = db.prepare(`SELECT ur.*, s.id as season_id
                FROM user_ranks ur 
                JOIN seasons s ON ur.season_id = s.id 
                WHERE ur.user_id = ? AND s.is_active = 1`)
    .get(req.user.userId);
  
  let pointsGained = calculateGuessPoints(similarity, isCorrect, 0);
  let coinsGained = 0;
  let newAchievements = [];
  let newWinStreak = user.win_streak;
  
  if (isCorrect) {
    newWinStreak = user.win_streak + 1;
    coinsGained = 10 + Math.min(newWinStreak * 5, 50);
    
    if (newWinStreak >= 3) {
      coinsGained += 20;
      newAchievements.push({ type: 'win_streak_3', name: '三连胜', reward: 20 });
    }
    if (newWinStreak >= 5) {
      coinsGained += 50;
      newAchievements.push({ type: 'win_streak_5', name: '五连胜', reward: 50 });
    }
    
    db.prepare('UPDATE users SET win_streak = ?, max_win_streak = MAX(max_win_streak, ?), total_wins = total_wins + 1, coins = coins + ? WHERE id = ?')
      .run(newWinStreak, newWinStreak, coinsGained, req.user.userId);
  } else {
    db.prepare('UPDATE users SET win_streak = 0 WHERE id = ?').run(req.user.userId);
    newWinStreak = 0;
  }
  
  const result = checkRankUp(
    userRank?.rank || '青铜',
    userRank?.stars || 0,
    userRank?.points || 0,
    pointsGained
  );
  
  if (userRank) {
    db.prepare(`UPDATE user_ranks SET rank = ?, stars = ?, points = ?, 
            total_guesses = total_guesses + 1, 
            correct_guesses = correct_guesses + ? 
            WHERE id = ?`)
      .run(result.newRank, result.newStars, result.newPoints, isCorrect ? 1 : 0, userRank.id);
  }
  
  db.prepare('INSERT OR IGNORE INTO user_items (user_id, item_type, count) VALUES (?, ?, 0)')
    .run(req.user.userId, 'hint');
  db.prepare('INSERT OR IGNORE INTO user_items (user_id, item_type, count) VALUES (?, ?, 0)')
    .run(req.user.userId, 'skip');
  
  res.json({
    similarity,
    isCorrect,
    targetWord: isCorrect ? dailyWord.target_word : null,
    pointsGained,
    coinsGained,
    rankUp: result.rankUp,
    newRank: result.newRank,
    winStreak: newWinStreak,
    newAchievements,
    userCoins: user.coins + coinsGained
  });
});

// 获取猜测历史
router.get('/guesses', authenticateToken, (req, res) => {
  const today = new Date().toISOString().split('T')[0];
  
  const guesses = db.prepare(`SELECT g.*, u.username 
          FROM guesses g 
          JOIN users u ON g.user_id = u.id
          JOIN daily_words dw ON g.daily_word_id = dw.id
          WHERE dw.date = ?
          ORDER BY g.similarity DESC, g.created_at ASC`)
    .all(today);
  
  res.json({ guesses: guesses || [] });
});

// 排行榜
router.get('/leaderboard', authenticateToken, (req, res) => {
  const leaderboard = db.prepare(`SELECT u.username, ur.points, ur.rank, ur.correct_guesses, u.win_streak
          FROM user_ranks ur
          JOIN users u ON ur.user_id = u.id
          JOIN seasons s ON ur.season_id = s.id
          WHERE s.is_active = 1
          ORDER BY ur.points DESC
          LIMIT 50`).all();
  
  res.json({ leaderboard: leaderboard || [] });
});

// 统计数据
router.get('/stats', authenticateToken, (req, res) => {
  const today = new Date().toISOString().split('T')[0];
  
  const users = db.prepare('SELECT COUNT(*) as count FROM users').get();
  const guesses = db.prepare(`SELECT COUNT(*) as count FROM guesses g
            JOIN daily_words dw ON g.daily_word_id = dw.id
            WHERE dw.date = ?`).get(today);
  const players = db.prepare(`SELECT COUNT(DISTINCT user_id) as count FROM guesses g
              JOIN daily_words dw ON g.daily_word_id = dw.id
              WHERE dw.date = ?`).get(today);
  
  const user = db.prepare('SELECT coins, win_streak, max_win_streak, total_wins FROM users WHERE id = ?').get(req.user.userId);
  const items = db.prepare('SELECT item_type, count FROM user_items WHERE user_id = ?').all(req.user.userId);
  
  res.json({
    totalUsers: users.count,
    todayGuesses: guesses.count,
    todayPlayers: players.count,
    user: user,
    items: items || []
  });
});

// 使用道具
router.post('/use-item', authenticateToken, (req, res) => {
  const { itemType } = req.body;
  const item = db.prepare('SELECT * FROM user_items WHERE user_id = ? AND item_type = ?').get(req.user.userId, itemType);
  
  if (!item || item.count <= 0) {
    return res.status(400).json({ error: '道具不足' });
  }
  
  db.prepare('UPDATE user_items SET count = count - 1 WHERE user_id = ? AND item_type = ?').run(req.user.userId, itemType);
  
  if (itemType === 'hint') {
    const today = new Date().toISOString().split('T')[0];
    const dailyWord = db.prepare(`SELECT dw.*, w.word FROM daily_words dw JOIN words w ON dw.word_id = w.id WHERE dw.date = ?`).get(today);
    if (dailyWord && dailyWord.revealed_chars < dailyWord.word.length) {
      db.prepare('UPDATE daily_words SET revealed_chars = revealed_chars + 1 WHERE id = ?').run(dailyWord.id);
    }
  }
  
  res.json({ success: true });
});

// 购买道具
router.post('/buy-item', authenticateToken, (req, res) => {
  const { itemType } = req.body;
  const prices = { hint: 20, skip: 30 };
  const price = prices[itemType];
  
  const user = db.prepare('SELECT coins FROM users WHERE id = ?').get(req.user.userId);
  if (user.coins < price) {
    return res.status(400).json({ error: '金币不足' });
  }
  
  db.prepare('UPDATE users SET coins = coins - ? WHERE id = ?').run(price, req.user.userId);
  db.prepare('INSERT OR REPLACE INTO user_items (user_id, item_type, count) VALUES (?, ?, COALESCE((SELECT count FROM user_items WHERE user_id = ? AND item_type = ?), 0) + 1)')
    .run(req.user.userId, itemType, req.user.userId, itemType);
  
  res.json({ success: true, newCoins: user.coins - price });
});

module.exports = router;
